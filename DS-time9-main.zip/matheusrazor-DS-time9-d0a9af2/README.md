# Engventure
> O RPG oficial das engenharias da Faculdade do Gama - UnB

## 🎮 Sobre o projeto
A ideia principal do jogo é introduzir o público infantil às engenharias da UnB campus Gama. Faremos isso com um RPG simples, em que cada engenharia ganhará sua arena própria com seus fatos e curiosidades, assim como um desafio único na forma de um minijogo.
## 📬 Política de commit
Quando realizar seu commit, escolha a branch wip. Depois de conferir se o commit realmente foi aquilo que se esperava e verificar erros, faça um pull request da branch wip para a main e espere ser aprovado.
## 🤝 Quem somos?
- Arthur
- Breno
- Gabriel
- Geovanna
- Maria
- Matheus
- Natan
